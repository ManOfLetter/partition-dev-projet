"""
@file morph_lines_detection.py
@brief Use morphology transformations for extracting horizontal and vertical lines sample code
"""
import numpy as np
import sys
import cv2 as cv


def show_wait_destroy(winname, img):
    cv.imshow(winname, img)
    cv.moveWindow(winname, 500, 0)
    cv.waitKey(0)
    cv.destroyWindow(winname)


def main(argv):

    # Charge l'image dans une variable
    src = cv.imread("MadWorld.jpg", cv.IMREAD_COLOR)  

    # [gray]
    # Transforme l'image couleur en image grise
    if len(src.shape) != 2:
        gray = cv.cvtColor(src, cv.COLOR_BGR2GRAY)
    else:
        gray = src    

    # [bin]
    # Applique le complément de couleur, inverse le noir et le blanc
    gray = cv.bitwise_not(gray)
    bw = cv.adaptiveThreshold(gray, 255, cv.ADAPTIVE_THRESH_MEAN_C, \
                                cv.THRESH_BINARY, 15, -2)
    show_wait_destroy("bin", bw)    

    # [init]
    # Créé l'image qui sera utilisée pour garder les lignes horizontales
    horizontal = np.copy(bw)

    # [horiz]
    # Spécifie la taille sur l'axe horizontal
    cols = horizontal.shape[1]
    horizontal_size = cols // 30

    # Créé l'élement structurel pour extraire les lignes horizontales avec des opérations
    horizontalStructure = cv.getStructuringElement(cv.MORPH_RECT, (horizontal_size, 1))

    # Applique les opérations de morphing
    horizontal = cv.erode(horizontal, horizontalStructure)
    #horizontal = cv.dilate(horizontal, horizontalStructure)
    
    # Affiche les lignes horizontales extraites
    cv.imwrite('Image.jpg',horizontal)

    imagef = cv.imread("Image.jpg")

    ligne = 0

    hauteur = imagef.shape[0]
    print ("Hauteur = ", hauteur)

    for i in range(1,hauteur-1):
        (b, g, r) = imagef[i,500]
        (b2, g2, r2) = imagef[i-1,500]

        if (b>200 and g>200 and r>200):

            if (b2<100 and g2<100 and r2<100):
                ligne=ligne+1
                #print (b,g,r) # on affiche les 3 intensites representant notre couleur

                for j in range(500,550):
                    imagef[i,j] = (255,0,255)
        
        imagef[i-1,500] = (0,255,255) # le pixel [i,j] change de couleur

    print ("Nombre de lignes = ", ligne)

    show_wait_destroy("imagef", imagef)    

    return 0

if __name__ == "__main__":
    main(sys.argv[1:])